# nodered-serverless
node-red serverless POC
